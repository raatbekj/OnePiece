package com.example.note;

public interface OnItem {
    void click(int position);
}
